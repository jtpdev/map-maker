# map-maker

A simple map maker with electronjs.

![example](https://media.giphy.com/media/1iRcFkgZwvA8R8IQ13/giphy.gif)
